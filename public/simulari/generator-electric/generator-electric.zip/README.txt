PRAXIS SCIENCE LAB
RO / EN · offline · Praxis / Vivid · Touch mode

RO: Pe calculator, deschide index.html în browser, după dezarhivarea completă. Nu sunt necesare internetul, Node sau instalări. Home revine la începutul lecției. Pentru biblioteca întreagă și Android prin LAN folosește pachetul Praxis-Fizica-local.zip și Porneste-local.cmd pe PC.

EN: On a computer, extract all files, then open index.html in your browser. No internet, Node or installation is required. Home returns to the lesson start. For the full library and Android over LAN, use Praxis-Fizica-local.zip and run Porneste-local.cmd on the PC.

RO: Pe Android, Chrome poate refuza deschiderea din Descărcări. Metoda verificată fără rețea folosește dosarul local al Chrome, pregătit prin USB cu ADB. Consultă secțiunea Android din README.md al proiectului.
EN: On Android, Chrome may deny direct access from Downloads. The tested offline method uses the Chrome local folder, prepared over USB with ADB. See the Android section of the project README.md.

RO: Ansamblul 3D necesită un browser cu WebGL 2.
EN: The 3D assembly requires a browser with WebGL 2.
