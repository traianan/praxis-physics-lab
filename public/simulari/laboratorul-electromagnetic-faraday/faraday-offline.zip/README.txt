Praxis · Faraday
RO: Dezarhivează complet și deschide index.html. RO/EN și resursele 3D sunt incluse. Este necesar WebGL 2.
EN: Extract all files and open index.html. RO/EN and 3D resources are included. WebGL 2 required.

RO: Pe Android, deschide o dată https://praxis-physics-lab.vercel.app/offline/index.html în Chrome cu internet. Apoi selectează acest ZIP în pagina Arhive offline, chiar și fără conexiune. Deschide lecția din Lecții salvate.
EN: On Android, open https://praxis-physics-lab.vercel.app/offline/index.html once in Chrome while online. Then choose this ZIP on the offline page, even without a connection. Open it from the saved lessons list.
