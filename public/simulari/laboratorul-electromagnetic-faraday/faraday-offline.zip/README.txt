Praxis · Faraday
RO: Dezarhivează complet și deschide index.html. RO/EN și resursele 3D sunt incluse. Este necesar WebGL 2.
EN: Extract all files and open index.html. RO/EN and 3D resources are included. WebGL 2 required.

RO: Pe Android, Chrome poate refuza accesul din Descărcări. Consultă secțiunea Android din README.md al proiectului pentru metoda prin USB cu ADB.
EN: On Android, Chrome may deny access from Downloads. See the Android section of the project README.md for the USB method using ADB.
