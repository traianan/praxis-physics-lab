Praxis · Faraday
RO: Dezarhivează complet și deschide index.html. RO/EN și resursele 3D sunt incluse. Este necesar WebGL 2.
EN: Extract all files and open index.html. RO/EN and 3D resources are included. WebGL 2 required.
