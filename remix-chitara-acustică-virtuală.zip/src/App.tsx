import { useCallback, useEffect, useMemo, useState } from 'react';
import { BookMarked, BookOpen, CheckCircle2, Compass, Monitor, RotateCcw, Sliders, Volume2, VolumeX } from 'lucide-react';
import { audioEngine } from './audio/AudioEngine';
import { DictionaryView } from './components/DictionaryView';
import { GuideView } from './components/GuideView';
import { OnboardingTour, TOUR_STORAGE_KEY } from './components/OnboardingTour';
import { Module1Notes } from './components/modules/Module1Notes';
import { Module2String } from './components/modules/Module2String';
import { Module3Harmonics } from './components/modules/Module3Harmonics';
import { Module4Temperament } from './components/modules/Module4Temperament';
import { Module5Scales } from './components/modules/Module5Scales';
import { Module6Chords } from './components/modules/Module6Chords';
import { Module7Spectrum } from './components/modules/Module7Spectrum';
import { Module8Sandbox } from './components/modules/Module8Sandbox';
import { LabModuleId, LabPreferences, MissionId, NotationSystem, TopSection, TuningId } from './types/guitar';
import { GUIDED_MISSIONS, buildStringsForTuning } from './utils/musicTheory';

const STORAGE_KEY = 'chitara_acustica_virtuala_prefs_v1';

const DEFAULT_PREFS: LabPreferences = {
  notation: 'anglo',
  volume: 0.8,
  soundEnabled: true,
  boardMode: false,
  tuning: 'standard',
  activeModule: 'string',
  completedMissions: [],
};

const MODULES: Array<{ id: LabModuleId; label: string }> = [
  { id: 'notes', label: '1. Nota și frecvența' },
  { id: 'string', label: '2. Coarda chitarei' },
  { id: 'harmonics', label: '3. Armonicele' },
  { id: 'temperament', label: '4. Temperamentul egal' },
  { id: 'scales', label: '5. Game și intervale' },
  { id: 'chords', label: '6. Acorduri' },
  { id: 'spectrum', label: '7. Spectrul chitarei' },
  { id: 'sandbox', label: '8. Laborator liber' },
];

function loadPreferences(): LabPreferences {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_PREFS;
    const parsed = JSON.parse(raw) as Partial<LabPreferences>;
    return {
      ...DEFAULT_PREFS,
      ...parsed,
      completedMissions: Array.isArray(parsed.completedMissions) ? parsed.completedMissions : [],
    };
  } catch {
    return DEFAULT_PREFS;
  }
}

export default function App() {
  const [prefs, setPrefs] = useState<LabPreferences>(loadPreferences);
  const [topSection, setTopSection] = useState<TopSection>('lab');
  const [showPrefsPopover, setShowPrefsPopover] = useState<boolean>(false);
  const [missionBanner, setMissionBanner] = useState<string | null>(null);
  const [showTour, setShowTour] = useState<boolean>(false);

  const strings = useMemo(() => buildStringsForTuning(prefs.tuning), [prefs.tuning]);

  useEffect(() => {
    try {
      const done = window.localStorage.getItem(TOUR_STORAGE_KEY);
      if (done !== 'true') {
        const timer = window.setTimeout(() => setShowTour(true), 350);
        return () => window.clearTimeout(timer);
      }
    } catch {
      // Ignore storage read errors
    }
  }, []);

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(prefs));
    } catch {
      // Ignore storage quota errors
    }
  }, [prefs]);

  useEffect(() => {
    audioEngine.setVolume(prefs.volume);
    audioEngine.setMuted(!prefs.soundEnabled);
  }, [prefs.volume, prefs.soundEnabled]);

  const setActiveModule = useCallback((id: LabModuleId) => {
    setTopSection('lab');
    setPrefs((prev) => (prev.activeModule === id ? prev : { ...prev, activeModule: id }));
  }, []);

  const handleCompleteMission = (id: MissionId) => {
    setPrefs((prev) => {
      if (prev.completedMissions.includes(id)) return prev;
      const mission = GUIDED_MISSIONS.find((m) => m.id === id);
      if (mission) {
        setMissionBanner(`Misiune realizată: ${mission.title}`);
        window.setTimeout(() => setMissionBanner(null), 4500);
      }
      return {
        ...prev,
        completedMissions: [...prev.completedMissions, id],
      };
    });
  };

  const resetLab = () => {
    audioEngine.stopAll();
    setPrefs(DEFAULT_PREFS);
    setTopSection('lab');
    setShowPrefsPopover(false);
  };

  return (
    <div className={`min-h-screen bg-[#f5f7f5] text-[#13221d] ${prefs.boardMode ? 'board-mode' : ''}`}>
      {/* Clean 3-zone Top Header matching visual architecture */}
      <header className="bg-white border-b border-[#d8e2dc]">
        <div className="max-w-[1380px] mx-auto px-4 sm:px-6 h-14 flex items-center justify-between gap-8">
          {/* Zone 1: Single-line Brand Wordmark */}
          <a
            href="#top"
            onClick={(e) => {
              e.preventDefault();
              setTopSection('lab');
            }}
            className="text-base font-bold tracking-tight text-[#0d4a3e] whitespace-nowrap shrink-0"
          >
            Chitara acustică virtuală
          </a>

          {/* Zone 2: 5 concise single-line text navigation links */}
          <nav className="hidden md:flex items-center gap-6 text-xs font-medium text-[#53665f]">
            <button
              type="button"
              onClick={() => setActiveModule('notes')}
              className="hover:text-[#0d4a3e] hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Note și frecvențe
            </button>
            <button
              type="button"
              onClick={() => setActiveModule('string')}
              className="hover:text-[#0d4a3e] hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Coarda chitarei
            </button>
            <button
              type="button"
              onClick={() => setActiveModule('harmonics')}
              className="hover:text-[#0d4a3e] hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Armonicele
            </button>
            <button
              type="button"
              onClick={() => setActiveModule('spectrum')}
              className="hover:text-[#0d4a3e] hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Spectrul Fourier
            </button>
            <button
              type="button"
              onClick={() => setActiveModule('sandbox')}
              className="hover:text-[#0d4a3e] hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Laborator liber
            </button>
          </nav>

          {/* Zone 3: 1 primary action */}
          <div className="shrink-0">
            <button
              type="button"
              data-tour-id="sound-toggle-btn"
              onClick={() => setPrefs((p) => ({ ...p, soundEnabled: !p.soundEnabled }))}
              className={`px-3.5 py-1.5 rounded-lg border text-xs font-semibold flex items-center gap-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                prefs.soundEnabled
                  ? 'border-[#0d4a3e]/30 bg-[#edf3f0] text-[#0d4a3e] hover:bg-[#dce8e2]'
                  : 'border-[#d8e2dc] bg-white text-[#53665f] hover:bg-[#fafcfa]'
              }`}
            >
              {prefs.soundEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
              <span>{prefs.soundEnabled ? 'Sunet activ' : 'Sunet oprit'}</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main id="top" className="max-w-[1380px] mx-auto px-4 sm:px-6 py-5 space-y-4">
        {/* Deep Forest-Green Banner matching screenshot */}
        <section className="rounded-xl bg-[#0d4a3e] text-white px-6 py-4 flex flex-wrap items-baseline justify-between gap-3">
          <div className="flex flex-wrap items-baseline gap-x-4 gap-y-1">
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight" style={{ textWrap: 'balance' }}>
              Chitara acustică virtuală
            </h1>
            <p className="text-xs sm:text-sm text-[#c8dfd8]">
              Laborator interactiv de fizică a sunetului, note muzicale, armonice și analiză Fourier
            </p>
          </div>
          <div className="text-xs font-mono text-[#c8dfd8] tabular-nums">
            Misiuni: {prefs.completedMissions.length}/{GUIDED_MISSIONS.length}
          </div>
        </section>

        {/* Workspace Toolbar Row */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-1 p-1 rounded-lg bg-white border border-[#d8e2dc]">
            <button
              type="button"
              onClick={() => setTopSection('lab')}
              className={`px-3.5 py-1.5 rounded-md text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                topSection === 'lab'
                  ? 'bg-[#0d4a3e] text-white'
                  : 'text-[#53665f] hover:text-[#13221d]'
              }`}
            >
              <Sliders className="w-3.5 h-3.5" />
              <span>Laborator interactiv</span>
            </button>
            <button
              type="button"
              onClick={() => setTopSection('guide')}
              className={`px-3.5 py-1.5 rounded-md text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                topSection === 'guide'
                  ? 'bg-[#0d4a3e] text-white'
                  : 'text-[#53665f] hover:text-[#13221d]'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>Ghid și formule</span>
            </button>
            <button
              type="button"
              onClick={() => setTopSection('dictionary')}
              className={`px-3.5 py-1.5 rounded-md text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                topSection === 'dictionary'
                  ? 'bg-[#0d4a3e] text-white'
                  : 'text-[#53665f] hover:text-[#13221d]'
              }`}
            >
              <BookMarked className="w-3.5 h-3.5" />
              <span>Dicționar</span>
            </button>
          </div>

          <div className="relative flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => setShowTour(true)}
              className="px-3 py-1.5 rounded-lg border border-[#d8e2dc] bg-white hover:bg-[#edf3f0] text-xs font-medium text-[#0d4a3e] flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Compass className="w-3.5 h-3.5" />
              <span>Tur ghidat</span>
            </button>

            <button
              type="button"
              onClick={() => setPrefs((p) => ({ ...p, boardMode: !p.boardMode }))}
              className={`px-3 py-1.5 rounded-lg border text-xs font-medium flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                prefs.boardMode
                  ? 'bg-[#0d4a3e] text-white border-[#0d4a3e]'
                  : 'bg-white text-[#13221d] border-[#d8e2dc] hover:bg-[#edf3f0]'
              }`}
            >
              <Monitor className="w-3.5 h-3.5" />
              <span>Mod tablă</span>
            </button>

            <button
              type="button"
              onClick={() => setShowPrefsPopover((s) => !s)}
              className="px-3 py-1.5 rounded-lg border border-[#d8e2dc] bg-white hover:bg-[#edf3f0] text-xs font-medium text-[#13221d] whitespace-nowrap shrink-0 cursor-pointer"
            >
              Preferințe laborator
            </button>

            {showPrefsPopover && (
              <div className="absolute right-0 top-10 z-30 w-72 rounded-xl border border-[#d8e2dc] bg-white p-4 shadow-lg space-y-3.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-[#13221d]">Preferințe laborator</span>
                  <button
                    type="button"
                    onClick={() => setShowPrefsPopover(false)}
                    className="text-xs text-[#53665f] hover:text-[#13221d] cursor-pointer"
                  >
                    Închide
                  </button>
                </div>

                <div className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-[#53665f]">Volum general</span>
                    <span className="font-mono font-semibold tabular-nums">{Math.round(prefs.volume * 100)}%</span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={1}
                    step={0.05}
                    value={prefs.volume}
                    onChange={(e) => setPrefs((p) => ({ ...p, volume: Number(e.target.value) }))}
                    className="lab-slider w-full"
                  />
                </div>

                <div className="space-y-1">
                  <span className="block text-xs text-[#53665f]">Notație muzicală</span>
                  <div className="grid grid-cols-2 gap-1 p-1 rounded-lg bg-[#edf3f0]">
                    {(['anglo', 'solfege'] as NotationSystem[]).map((n) => (
                      <button
                        key={n}
                        type="button"
                        onClick={() => setPrefs((p) => ({ ...p, notation: n }))}
                        className={`py-1 rounded text-xs font-medium cursor-pointer ${
                          prefs.notation === n ? 'bg-[#0d4a3e] text-white' : 'text-[#53665f]'
                        }`}
                      >
                        {n === 'anglo' ? 'C – D – E' : 'Do – Re – Mi'}
                      </button>
                    ))}
                  </div>
                </div>

                <button
                  type="button"
                  onClick={resetLab}
                  className="w-full py-2 px-3 rounded-lg border border-[#d8e2dc] bg-[#fafcfa] hover:bg-[#edf3f0] text-xs font-medium text-[#13221d] flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Resetează setările laboratorului</span>
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Mission completed notification */}
        {missionBanner && (
          <div className="rounded-xl border border-[#0d4a3e]/30 bg-[#edf3f0] px-4 py-2.5 flex items-center gap-2.5 text-xs font-semibold text-[#0d4a3e]">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{missionBanner}</span>
          </div>
        )}

        {topSection === 'lab' ? (
          <>
            {/* 8-Module Navigation Strip */}
            <div
              data-tour-id="module-strip"
              className="rounded-xl border border-[#d8e2dc] bg-white p-1.5 overflow-x-auto"
            >
              <div className="flex items-center gap-1 min-w-max">
                {MODULES.map((m) => {
                  const active = prefs.activeModule === m.id;
                  return (
                    <button
                      key={m.id}
                      type="button"
                      data-tour-id={`module-tab-${m.id}`}
                      onClick={() => setActiveModule(m.id)}
                      className={`px-3 py-2 rounded-lg text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                        active
                          ? 'bg-[#0d4a3e] text-white'
                          : 'text-[#53665f] hover:bg-[#edf3f0] hover:text-[#13221d]'
                      }`}
                    >
                      {m.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Active Module Workspace */}
            <div>
              {prefs.activeModule === 'notes' && (
                <Module1Notes
                  notation={prefs.notation}
                  onChangeNotation={(n) => setPrefs((p) => ({ ...p, notation: n }))}
                  strings={strings}
                />
              )}
              {prefs.activeModule === 'string' && (
                <Module2String
                  strings={strings}
                  notation={prefs.notation}
                  onCompleteMission={handleCompleteMission}
                />
              )}
              {prefs.activeModule === 'harmonics' && (
                <Module3Harmonics
                  notation={prefs.notation}
                  onCompleteMission={handleCompleteMission}
                />
              )}
              {prefs.activeModule === 'temperament' && (
                <Module4Temperament onCompleteMission={handleCompleteMission} />
              )}
              {prefs.activeModule === 'scales' && (
                <Module5Scales strings={strings} notation={prefs.notation} />
              )}
              {prefs.activeModule === 'chords' && (
                <Module6Chords
                  strings={strings}
                  notation={prefs.notation}
                  onCompleteMission={handleCompleteMission}
                />
              )}
              {prefs.activeModule === 'spectrum' && (
                <Module7Spectrum strings={strings} notation={prefs.notation} />
              )}
              {prefs.activeModule === 'sandbox' && (
                <Module8Sandbox
                  strings={strings}
                  tuning={prefs.tuning}
                  onChangeTuning={(t: TuningId) => setPrefs((p) => ({ ...p, tuning: t }))}
                  notation={prefs.notation}
                  completedMissions={prefs.completedMissions}
                  onCompleteMission={handleCompleteMission}
                  onNavigateModule={setActiveModule}
                />
              )}
            </div>
          </>
        ) : topSection === 'guide' ? (
          <GuideView onOpenModule={setActiveModule} />
        ) : (
          <DictionaryView onOpenModule={setActiveModule} />
        )}
      </main>

      <OnboardingTour
        isOpen={showTour}
        onClose={() => setShowTour(false)}
        onSelectModule={setActiveModule}
        onSelectSection={setTopSection}
      />
    </div>
  );
}
